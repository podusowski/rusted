/*!
	@file
	@author		Albert Semenov
	@date		01/2009
	@module
*/
#pragma once

#include "Delegate1.h"
#include "Delegate2.h"
#include "Delegate3.h"
#include "Delegate4.h"
#include "Delegate5.h"

#include "Delegate3_Ref2.h"
