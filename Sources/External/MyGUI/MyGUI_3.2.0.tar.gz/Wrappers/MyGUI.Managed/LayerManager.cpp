/*!
	@file
	@author		Albert Semenov
	@date		02/2010
	@module
*/

#include "LayerManager.h"
