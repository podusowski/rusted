/*!
	@file
	@author		Albert Semenov
	@date		01/2009
	@module
*/

#include "ExportMarshalingType.h"

namespace Export
{

	Convert< const MyGUI::DDItemInfo& >::DDItemInfo Convert< const MyGUI::DDItemInfo& >::mHolder;

}
