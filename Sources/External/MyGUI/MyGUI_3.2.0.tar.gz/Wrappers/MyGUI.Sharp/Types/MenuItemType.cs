using System;

namespace MyGUI.Sharp
{
    public enum MenuItemType : int
    {
        Normal = 0,
        Popup = 1,
        Separator = 2,
    }
}
