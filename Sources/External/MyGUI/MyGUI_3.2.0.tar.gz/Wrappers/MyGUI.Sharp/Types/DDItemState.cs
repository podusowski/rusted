using System;

namespace MyGUI.Sharp
{
    public enum DDItemState : int
    {
        None = 0,
        Start = 1,
        End = 2,
        Miss = 3,
        Accept = 4,
        Refuse = 5,
    }
}
