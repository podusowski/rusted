using System;

namespace MyGUI.Sharp
{
    public enum FlowDirection : int
    {
        LeftToRight = 0,
        RightToLeft = 1,
        TopToBottom = 2,
        BottomToTop = 3,
    }
}
