There you can find basic information about how to build MyGUI:
	http://www.ogre3d.org/tikiwiki/MyGUI+Compiling
