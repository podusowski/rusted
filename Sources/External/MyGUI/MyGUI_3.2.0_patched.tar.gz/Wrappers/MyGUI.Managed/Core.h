/*!
	@file
	@author		Albert Semenov
	@date		01/2009
	@module
*/
#pragma once

#include "Types.h"
#include "Delegates.h"
#include "WidgetHolder.h"
#include "MarshalingWidget.h"
