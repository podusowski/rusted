using System;

namespace MyGUI.Sharp
{
    public enum WidgetStyle : int
    {
        Child = 0,
        Popup = 1,
        Overlapped = 2,
    }
}
