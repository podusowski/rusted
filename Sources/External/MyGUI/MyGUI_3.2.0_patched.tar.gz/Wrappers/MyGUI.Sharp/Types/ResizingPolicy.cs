using System;

namespace MyGUI.Sharp
{
    public enum ResizingPolicy : int
    {
        Auto = 0,
        Fixed = 1,
        Fill = 2,
    }
}
