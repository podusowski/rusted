using System;

namespace TestApp.Sharp
{
    public class Test_MenuBar
    {
        public static void Test()
        {
        }
    }
}
