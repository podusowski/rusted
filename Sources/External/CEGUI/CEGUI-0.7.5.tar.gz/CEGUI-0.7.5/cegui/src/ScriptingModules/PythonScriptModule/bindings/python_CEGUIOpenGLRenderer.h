#include "CEGUIString.h"
#include "CEGUIGeometryBuffer.h"
#include "CEGUITexture.h"
#include "CEGUITextureTarget.h"
#include "CEGUIRenderingRoot.h"

#include "RendererModules/OpenGL/CEGUIOpenGLRenderer.h"
